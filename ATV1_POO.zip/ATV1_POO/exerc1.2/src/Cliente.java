// Classe Cliente
public class Cliente {
    String nome;
    int idade;
    String email;

    public void mostrarInfo() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("E-mail: " + email);
    }

    public void comprarLivro(String titulo) {
        System.out.println(nome + " comprou o livro: " + titulo);
    }
}
