
public class ProjetoCliente {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente();
        cliente1.nome = "Ana";
        cliente1.idade = 25;
        cliente1.email = "ana@email.com";

        Cliente cliente2 = new Cliente();
        cliente2.nome = "João";
        cliente2.idade = 30;
        cliente2.email = "joao@email.com";

        cliente1.mostrarInfo();
        cliente1.comprarLivro("O Senhor dos Anéis");

        cliente2.mostrarInfo();
        cliente2.comprarLivro("Harry Potter e a Pedra Filosofal");
    }
}
