public class ProjetoAluno {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno();
        aluno1.nome = "Maria";
        aluno1.matricula = 101;
        aluno1.notaAv1 = 8.0;
        aluno1.notaAv2 = 7.5;

        Aluno aluno2 = new Aluno();
        aluno2.nome = "João";
        aluno2.matricula = 102;
        aluno2.notaAv1 = 5.0;
        aluno2.notaAv2 = 6.0;

        aluno1.mostrarDados();
        aluno1.verificarAprovacao();

        aluno2.mostrarDados();
        aluno2.verificarAprovacao();


        System.out.println("\nApós atualização:");
        aluno2.mostrarDados();
        aluno2.verificarAprovacao();
    }
}
