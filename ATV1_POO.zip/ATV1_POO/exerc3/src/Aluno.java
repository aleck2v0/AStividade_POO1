// Classe Aluno
public class Aluno {
    String nome;
    int matricula;
    double notaAv1;
    double notaAv2;

    // Mostrar os dados
    public void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Matrícula: " + matricula);
        System.out.println("Nota AV1: " + notaAv1);
        System.out.println("Nota AV2: " + notaAv2);
    }

    // Calcular média
    public double calcularMedia() {
        return (notaAv1 + notaAv2) / 2;
    }

    // Verificar aprovação
    public void verificarAprovacao() {
        double media = calcularMedia();
        if (media >= 7) {
            System.out.println("Aprovado com média: " + media);
        } else {
            System.out.println("Reprovado com média: " + media);
        }
    }
}

// Classe Principal