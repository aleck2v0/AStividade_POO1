
// Classe principal
public class ProjetoCarro {
    public static void main(String[] args) {
        // Criando dois carros
        Carro carro1 = new Carro();
        carro1.marca = "Toyota";
        carro1.modelo = "Corolla";
        carro1.ano = 2020;

        Carro carro2 = new Carro();
        carro2.marca = "Honda";
        carro2.modelo = "Civic";
        carro2.ano = 2019;

        // Mostrando informações
        carro1.mostrarInfo();
        carro1.ligar();

        carro2.mostrarInfo();
        carro2.ligar();

        // Alterando atributos do carro2
        carro2.ano = 2022;
        carro2.modelo = "Civic Turbo";

        System.out.println("\nApós alteração:");
        carro2.mostrarInfo();
    }
}
