public class Carro {
    String marca;
    String modelo;
    int ano;

    // Mostrar informações
    public void mostrarInfo() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Ano: " + ano);
    }

    // Ligar carro
    public void ligar() {
        System.out.println("O carro " + modelo + " está ligado!");
    }
}