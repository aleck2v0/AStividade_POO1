
public class ProjetoLivraria {
    public static void main(String[] args) {

        Livro livro1 = new Livro();
        livro1.titulo = "O Senhor dos Anéis";
        livro1.autor = "J.R.R. Tolkien";
        livro1.preco = 80.0;

        Livro livro2 = new Livro();
        livro2.titulo = "Harry Potter e a Pedra Filosofal";
        livro2.autor = "J.K. Rowling";
        livro2.preco = 50.0;

        livro1.mostrarInfo();
        livro2.mostrarInfo();

        livro2.preco = 45.0;
        System.out.println("\nApós alteração:");
        livro2.mostrarInfo();

        livro1.aplicarDesconto(10);
        livro2.aplicarDesconto(5);
    }
}
