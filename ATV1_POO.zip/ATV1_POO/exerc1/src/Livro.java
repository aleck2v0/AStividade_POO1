
public class Livro {
    String titulo;
    String autor;
    double preco;

    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Preço: R$" + preco);
    }

    public void aplicarDesconto(double percentual) {
        preco -= preco * (percentual / 100);
        System.out.println("Desconto de " + percentual + "% aplicado. Novo preço: R$" + preco);
    }
}