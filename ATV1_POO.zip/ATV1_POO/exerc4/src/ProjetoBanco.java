public class ProjetoBanco {
    public static void main (String[] args) {

        ContaBancaria conta1 = new ContaBancaria();
        conta1.numeroConta = "12345";
        conta1.titular = "Carlos";
        conta1.saldo = 500.0;

        ContaBancaria conta2 = new ContaBancaria();
        conta2.numeroConta = "67890";
        conta2.titular = "Ana";
        conta2.saldo = 1000.0;

        // Operações conta1
        conta1.consultarSaldo();
        conta1.depositar(200);
        conta1.sacar(100);
        conta1.consultarSaldo();

        // Operações conta2
        conta2.consultarSaldo();
        conta2.sacar(1200);
        conta2.depositar(300);
        conta2.consultarSaldo();
    }
}